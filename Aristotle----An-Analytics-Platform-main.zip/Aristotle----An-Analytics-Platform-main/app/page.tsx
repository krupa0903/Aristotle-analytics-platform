'use client';
import Link from 'next/link';
import { Lock, Bot, Zap, Sun, Moon } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

export default function HomePage() {
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  const bg = isDark ? 'bg-[#1A1108] text-[#F5F0E8]' : 'bg-[#F5F0E8] text-[#2C1A0E]';
  const cardBg = isDark
    ? 'bg-[#211507] border border-[#3A2910] hover:border-[#A67C52]/40'
    : 'bg-white border border-[#C8A97E]/40 hover:border-[#A67C52] shadow-sm';
  const muted = isDark ? 'text-[#3B5E3A]' : 'text-[#5A3E1B]/70';

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-4 transition-colors duration-300 ${bg}`}>
      <button
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        className={`fixed top-5 right-5 p-2.5 rounded-full transition-all ${
          isDark
            ? 'bg-[#2A1C0A] hover:bg-[#3A2910] text-[#C8A97E]'
            : 'bg-white hover:bg-[#EDE8DF] text-[#5A3E1B] shadow-sm border border-[#C8A97E]/40'
        }`}
      >
        {isDark ? <Sun size={18} /> : <Moon size={18} />}
      </button>

      <div className="flex items-center gap-3 mb-4" style={{ animation: 'fadeIn 0.5s ease' }}>
        <div className="w-10 h-10 bg-[#5A3E1B] rounded-xl flex items-center justify-center">
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <circle cx="11" cy="11" r="8" stroke="#C8A97E" strokeWidth="1.5" fill="none"/>
            <line x1="11" y1="3" x2="11" y2="19" stroke="#C8A97E" strokeWidth="1.2"/>
            <line x1="3" y1="11" x2="19" y2="11" stroke="#C8A97E" strokeWidth="1.2"/>
            <circle cx="11" cy="11" r="2" fill="#A67C52"/>
          </svg>
        </div>
        <span className="text-3xl font-bold tracking-tight" style={{ fontFamily: "'DM Serif Display', serif" }}>
          Aristotle
        </span>
      </div>

      <p className={`text-center text-base max-w-md mb-12 leading-relaxed ${muted}`} style={{ animation: 'fadeIn 0.6s ease' }}>
        Privacy-first web analytics powered by AI. Observe every click, understand every pattern.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-3xl mb-12" style={{ animation: 'slideUp 0.5s ease' }}>
        {[
          { icon: <Lock size={24} className="text-[#3B5E3A]" />, title: 'Privacy First', desc: 'No cookies, no IP storage, fully GDPR compliant.' },
          { icon: <Bot size={24} className="text-[#3B5E3A]" />, title: 'AI-Powered', desc: 'Automatic anomaly detection and insights.' },
          { icon: <Zap size={24} className="text-[#2C3E50]" />, title: 'Lightning Fast', desc: 'Under 5KB tracking script. Zero performance impact.' },
        ].map((f, i) => (
          <div key={i} className={`rounded-2xl p-6 transition-all card-hover ${cardBg}`}>
            <div className="mb-3">{f.icon}</div>
            <h3 className="font-semibold text-base mb-1.5" style={{ fontFamily: "'DM Serif Display', serif" }}>{f.title}</h3>
            <p className={`text-sm leading-relaxed ${muted}`}>{f.desc}</p>
          </div>
        ))}
      </div>

      <div className="flex gap-4" style={{ animation: 'fadeIn 0.8s ease' }}>
        <Link href="/auth/signin" className="px-8 py-3 bg-[#5A3E1B] hover:bg-[#3B5E3A] text-[#F5F0E8] rounded-xl font-semibold text-sm transition-all hover:scale-105 active:scale-95">
          Sign In
        </Link>
        <Link href="/auth/signup" className={`px-8 py-3 rounded-xl font-semibold text-sm transition-all hover:scale-105 active:scale-95 border ${
          isDark ? 'border-[#3A2910] text-[#C8A97E] hover:bg-[#2A1C0A]' : 'border-[#C8A97E]/60 text-[#5A3E1B] hover:bg-[#EDE8DF]'
        }`}>
          Sign Up
        </Link>
      </div>

      <div className="mt-16 text-center" style={{ animation: 'fadeIn 1s ease' }}>
        <p className={`text-xs mb-3 ${muted}`}>Grounded in reason</p>
        <div className={`flex gap-8 text-sm font-medium ${muted}`}>
          {['Empirical', 'Grounded', 'Purpose-driven', 'Privacy-first'].map(b => (
            <span key={b} className="hover:text-[#3B5E3A] transition-colors cursor-default">{b}</span>
          ))}
        </div>
      </div>
    </div>
  );
}