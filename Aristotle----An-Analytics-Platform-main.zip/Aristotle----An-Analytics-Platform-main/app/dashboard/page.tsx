'use client';
import { useEffect, useState } from 'react';
import { useTheme } from '../../src/contexts/ThemeContext';
import { AlertTriangle, Eye, MousePointer, AlertCircle, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function DashboardPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [data, setData] = useState<any>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const siteId = localStorage.getItem('site_id') || 'demo-site';

    const fetchData = async () => {
      setIsRefreshing(true);
      try {
        const res = await fetch(`/api/data?site_id=${siteId}`);
        const json = await res.json();
        setData(json);
        setLastUpdated(new Date().toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit'
        }));
      } catch (err) {
        console.error('Failed to fetch:', err);
      } finally {
        setIsRefreshing(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  if (!data) return (
    <div className="flex items-center justify-center h-64 gap-3">
      <div className="w-5 h-5 border-2 border-[#A67C52] border-t-transparent rounded-full animate-spin" />
      <span className="text-[#A67C52]">Loading dashboard...</span>
    </div>
  );

  const trafficData = data.weeklyTraffic.map((d: any) => ({
    day: new Date(d.date).toLocaleDateString('en', { weekday: 'short' }),
    value: parseInt(d.views)
  }));

  const card = isDark ? 'bg-[#211507] border border-[#2A1C0A]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';
  const gridLine = isDark ? '#1E1E1E' : '#E5E7EB';
  const axisColor = isDark ? '#555' : '#9CA3AF';
  const tooltipBg = isDark ? '#1A1A1A' : '#fff';
  const tooltipBorder = isDark ? '#2A2A2A' : '#E5E7EB';

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>

      {/* LIVE INDICATOR */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${isRefreshing ? 'bg-yellow-400' : 'bg-green-500 animate-pulse'}`} />
          <span className={`text-xs font-medium ${isRefreshing ? 'text-yellow-400' : 'text-green-500'}`}>
            {isRefreshing ? 'Refreshing...' : 'Live — updates every 5s'}
          </span>
        </div>
        {lastUpdated && (
          <span className={`text-xs ${muted}`}>Last updated: {lastUpdated}</span>
        )}
      </div>

      {/* AI ANOMALY ALERT */}
      {data.aiInsight && (
        <div className="rounded-2xl border border-emerald-500/30 bg-[#3B5E3A]/5 p-4 flex items-start gap-3">
          <AlertTriangle size={18} className="text-[#3B5E3A] mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold text-[#3B5E3A] text-sm mb-0.5">AI Anomaly Alert</p>
            <p className={`text-sm ${muted}`}>{data.aiInsight}</p>
          </div>
        </div>
      )}

      {/* METRIC CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          {
            icon: <Eye size={20} />,
            value: data.todayViews.toLocaleString(),
            label: 'Pageviews Today',
            alert: false
          },
{ icon: <MousePointer size={20} />, value: (data.heatmapData.length + data.rageClicks).toLocaleString(), label: 'Total Clicks', alert: false },
          {
            icon: <AlertCircle size={20} />,
            value: data.rageClicks.toLocaleString(),
            label: 'Rage Clicks',
            alert: true
          },
          {
            icon: <Users size={20} />,
            value: data.funnel[0]?.users.toLocaleString() ?? '0',
            label: 'Funnel Users',
            alert: false
          },
        ].map((s, i) => (
          <div key={i} className={`rounded-2xl p-5 transition-all duration-300 ${
            s.alert ? 'bg-red-950/40 border border-red-500/40' : card
          }`}>
            <div className={`mb-2 ${s.alert ? 'text-red-400' : muted}`}>{s.icon}</div>
            <div className={`text-3xl font-bold mb-1 ${s.alert ? 'text-red-400' : ''}`}>{s.value}</div>
            <div className={`text-xs ${s.alert ? 'text-red-400/70' : muted}`}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* TRAFFIC CHART */}
      <div className={`rounded-2xl p-5 ${card}`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-sm">Traffic Last 7 Days</h3>
          <span className={`text-xs ${muted}`}>
            {data.weeklyTraffic.reduce((s: number, r: any) => s + parseInt(r.views), 0).toLocaleString()} total
          </span>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={trafficData} barSize={28}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridLine} vertical={false} />
            <XAxis dataKey="day" tick={{ fill: axisColor, fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: axisColor, fontSize: 12 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{
              background: tooltipBg,
              border: `1px solid ${tooltipBorder}`,
              borderRadius: 8,
              fontSize: 12
            }} />
            <Bar dataKey="value" fill="#7C3AED" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* TOP PAGES + TOP REFERRERS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        <div className={`rounded-2xl p-5 ${card}`}>
          <h3 className="font-semibold text-sm mb-4">Top Pages</h3>
          <div className={`grid grid-cols-2 pb-2 mb-1 border-b text-xs ${muted} ${
            isDark ? 'border-[#2A1C0A]' : 'border-gray-100'
          }`}>
            <span>Page</span>
            <span className="text-right">Views</span>
          </div>
          {data.topPages.length === 0 ? (
            <p className={`text-xs mt-3 ${muted}`}>No data yet</p>
          ) : (
            data.topPages.map((p: any, i: number) => (
              <div key={i} className={`grid grid-cols-2 py-2.5 border-b last:border-0 ${
                isDark ? 'border-[#2A1C0A]' : 'border-gray-50'
              }`}>
                <span className="text-sm font-mono truncate">{p.page}</span>
                <span className="text-sm text-right">{parseInt(p.views).toLocaleString()}</span>
              </div>
            ))
          )}
        </div>

        <div className={`rounded-2xl p-5 ${card}`}>
          <h3 className="font-semibold text-sm mb-4">Top Referrers</h3>
          <div className={`grid grid-cols-2 pb-2 mb-1 border-b text-xs ${muted} ${
            isDark ? 'border-[#2A1C0A]' : 'border-gray-100'
          }`}>
            <span>Source</span>
            <span className="text-right">Visits</span>
          </div>
          {!data.topReferrers || data.topReferrers.length === 0 ? (
            <p className={`text-xs mt-3 ${muted}`}>No referrer data yet</p>
          ) : (
            data.topReferrers.map((r: any, i: number) => (
              <div key={i} className={`grid grid-cols-2 py-2.5 border-b last:border-0 ${
                isDark ? 'border-[#2A1C0A]' : 'border-gray-50'
              }`}>
                <span className="text-sm font-mono truncate">{r.referrer || 'Direct'}</span>
                <span className="text-sm text-right">{parseInt(r.visits).toLocaleString()}</span>
              </div>
            ))
          )}
        </div>

      </div>

      {/* PRIVACY LABEL */}
      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4">Privacy Nutrition Label</h3>
        <div className="flex flex-wrap gap-2">
          {['No Cookies', 'No IP Storage', 'GDPR Compliant', 'Under 5KB Script', 'No Cross-Site Tracking'].map((b, i) => (
            <span key={i} className="px-4 py-1.5 rounded-full border border-[#3B5E3A]/50 text-[#3B5E3A] text-xs font-medium bg-[#3B5E3A]/5">
              {b}
            </span>
          ))}
        </div>
      </div>

    </div>
  );
}