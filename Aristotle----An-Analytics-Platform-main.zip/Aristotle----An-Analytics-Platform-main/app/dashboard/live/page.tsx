'use client';
import { useEffect, useState, useRef } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { Users, Globe, Activity } from 'lucide-react';
import { geoNaturalEarth1, geoPath } from 'd3-geo';
import { feature } from 'topojson-client';

interface LocationPoint {
  city: string;
  country: string;
  country_code: string;
  lat: number;
  lon: number;
  page: string;
  user_count: number;
  created_at: string;
}

interface ActivityItem {
  type: string;
  page: string;
  city: string;
  country: string;
  country_code: string;
  created_at: string;
}

interface CountryData {
  country: string;
  country_code: string;
  visits: number;
}

function flag(code: string) {
  if (!code) return '🌍';
  return code.toUpperCase().replace(/./g, c =>
    String.fromCodePoint(127397 + c.charCodeAt(0))
  );
}

function timeAgo(dateStr: string) {
  const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  return `${Math.floor(diff / 3600)}h ago`;
}

const W = 960;
const H = 500;

export default function LiveUsersPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  const [siteId, setSiteId] = useState('');
  const [liveCount, setLiveCount] = useState(0);
  const [locations, setLocations] = useState<LocationPoint[]>([]);
  const [topCountries, setTopCountries] = useState<CountryData[]>([]);
  const [recentActivity, setRecentActivity] = useState<ActivityItem[]>([]);
  const [lastUpdated, setLastUpdated] = useState('');
  const [countriesPaths, setCountriesPaths] = useState<string[]>([]);
  const [dotPositions, setDotPositions] = useState<{ x: number; y: number; loc: LocationPoint }[]>([]);

  useEffect(() => {
    setSiteId(localStorage.getItem('site_id') || '');
  }, []);

  // Load world map once
  useEffect(() => {
    fetch('https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json')
      .then(r => r.json())
      .then(world => {
        const projection = geoNaturalEarth1()
          .scale(153)
          .translate([W / 2, H / 2]);
        const pathGenerator = geoPath().projection(projection);
        const countries = feature(world as any, (world as any).objects.countries) as any;
        const paths = countries.features.map((f: any) => pathGenerator(f) || '');
        setCountriesPaths(paths);
      })
      .catch(err => console.error('World atlas load failed:', err));
  }, []);

  // Compute dot positions whenever locations change
  useEffect(() => {
    const projection = geoNaturalEarth1()
      .scale(153)
      .translate([W / 2, H / 2]);

    const dots = locations
      .filter(loc => loc.lat && loc.lon)
      .map(loc => {
        const coords = projection([loc.lon, loc.lat]);
        if (!coords) return null;
        return { x: coords[0], y: coords[1], loc };
      })
      .filter(Boolean) as { x: number; y: number; loc: LocationPoint }[];

    setDotPositions(dots);
  }, [locations]);

  const fetchData = async (id: string) => {
    if (!id) return;
    try {
      const res = await fetch(`/api/data?site_id=${id}`);
      const json = await res.json();
      setLiveCount(json.liveUserCount || 0);
      setLocations(json.liveLocations || []);
      setTopCountries(json.topCountries || []);
      setRecentActivity(json.recentActivity || []);
      setLastUpdated(new Date().toLocaleTimeString('en-IN', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      }));
    } catch (err) {
      console.error('Failed to fetch live data:', err);
    }
  };

  useEffect(() => {
    if (!siteId) return;
    fetchData(siteId);
    const interval = setInterval(() => fetchData(siteId), 5000);
    return () => clearInterval(interval);
  }, [siteId]);

  const card = isDark ? 'bg-[#211507] border border-[#2A1C0A]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';
  const mostActiveCountry = topCountries[0];

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold">Live Users Map</h1>
          <div className="flex items-center gap-1.5">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
            </span>
            <span className="text-xs text-red-400 font-medium">LIVE</span>
          </div>
        </div>
        {lastUpdated && <span className={`text-xs ${muted}`}>Updated: {lastUpdated}</span>}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className={`rounded-2xl p-5 ${card}`}>
          <div className="flex items-center gap-2 mb-2">
            <Users size={16} className="text-[#3B5E3A]" />
            <span className={`text-xs ${muted}`}>Active (last 5 min)</span>
          </div>
          <div className="text-3xl font-bold tabular-nums">{liveCount}</div>
        </div>
        <div className={`rounded-2xl p-5 ${card}`}>
          <p className={`text-xs ${muted} mb-2`}>Most Active Country</p>
          <p className="text-lg font-bold">
            {mostActiveCountry ? `${flag(mostActiveCountry.country_code)} ${mostActiveCountry.country}` : '—'}
          </p>
        </div>
        <div className={`rounded-2xl p-5 ${card}`}>
          <p className={`text-xs ${muted} mb-2`}>Locations Tracked</p>
          <p className="text-3xl font-bold">{locations.length}</p>
        </div>
      </div>

      {/* World Map */}
      <div className={`rounded-2xl overflow-hidden ${card}`}>
        <div className="px-5 pt-4 pb-2 flex items-center gap-2">
          <Globe size={14} className={muted} />
          <span className="text-sm font-semibold">Real-time Visitor Locations</span>
          <span className={`text-xs ${muted} ml-auto`}>Last 30 minutes</span>
        </div>
        <div className="relative" style={{ background: isDark ? '#0D1117' : '#DBEAFE' }}>
          <svg viewBox={`0 0 ${W} ${H}`} className="w-full block">
            {/* Ocean */}
            <rect width={W} height={H} fill={isDark ? '#0a1628' : '#DBEAFE'} />

            {/* Country paths from D3 */}
            <g>
              {countriesPaths.map((d, i) => (
                <path
                  key={i}
                  d={d}
                  fill={isDark ? '#1e3a5f' : '#BFDBFE'}
                  stroke={isDark ? '#2d5986' : '#93C5FD'}
                  strokeWidth="0.4"
                />
              ))}
            </g>

            {/* Equator */}
            <line
              x1="0" y1={H / 2} x2={W} y2={H / 2}
              stroke={isDark ? '#1e3a5f' : '#93C5FD'}
              strokeWidth="0.6"
              strokeDasharray="4,4"
              opacity="0.5"
            />

            {/* Location dots */}
            {dotPositions.map((dot, i) => (
              <g key={i}>
                <circle cx={dot.x} cy={dot.y} r="10" fill="rgba(124,58,237,0.15)">
                  <animate attributeName="r" values="6;18;6" dur={`${1.8 + (i % 4) * 0.3}s`} repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.8;0;0.8" dur={`${1.8 + (i % 4) * 0.3}s`} repeatCount="indefinite" />
                </circle>
                <circle cx={dot.x} cy={dot.y} r="5" fill="#7C3AED" />
                <circle cx={dot.x} cy={dot.y} r="2.5" fill="white" />
                <title>{flag(dot.loc.country_code)} {dot.loc.city}, {dot.loc.country} — {dot.loc.page}</title>
              </g>
            ))}
          </svg>

          {locations.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <p className="text-sm text-white/60 bg-black/30 px-4 py-2 rounded-xl">
                No visitors in the last 30 minutes — visit your tracked site!
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Bottom grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Top Countries */}
        <div className={`rounded-2xl p-5 ${card}`}>
          <h3 className="font-semibold text-sm mb-4">Top Countries</h3>
          {topCountries.length === 0 ? (
            <p className={`text-sm ${muted}`}>No location data yet</p>
          ) : (
            <div className="space-y-3">
              {topCountries.map((c, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-lg w-7">{flag(c.country_code)}</span>
                  <div className="flex-1">
                    <div className="flex justify-between text-sm mb-1">
                      <span className="font-medium">{c.country}</span>
                      <span className="text-[#3B5E3A] font-semibold">{c.visits}</span>
                    </div>
                    <div className={`h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-[#2A1C0A]' : 'bg-gray-100'}`}>
                      <div className="h-full bg-[#5A3E1B] rounded-full"
                        style={{ width: `${(Number(c.visits) / Number(topCountries[0].visits)) * 100}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Activity Feed */}
        <div className={`rounded-2xl p-5 ${card}`}>
          <div className="flex items-center gap-2 mb-4">
            <Activity size={14} className={muted} />
            <h3 className="font-semibold text-sm">Live Activity Feed</h3>
          </div>
          {recentActivity.length === 0 ? (
            <p className={`text-sm ${muted}`}>No recent activity</p>
          ) : (
            <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
              {recentActivity.map((a, i) => (
                <div key={i} className={`flex items-start gap-2.5 text-xs py-2 border-b last:border-0 ${isDark ? 'border-[#2A1C0A]' : 'border-gray-50'}`}>
                  <span className="text-base mt-0.5 shrink-0">{flag(a.country_code)}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                        a.type === 'pageview' ? 'bg-blue-500/10 text-blue-400' :
                        a.type === 'rage_click' ? 'bg-red-500/10 text-red-400' :
                        'bg-purple-500/10 text-purple-400'
                      }`}>{a.type}</span>
                      <span className="font-mono truncate">{a.page}</span>
                    </div>
                    <p className={`${muted} mt-0.5`}>
                      {a.city ? `${a.city}, ` : ''}{a.country || 'Unknown'} · {timeAgo(a.created_at)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
