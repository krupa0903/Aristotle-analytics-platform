'use client';
import { useEffect, useState } from 'react';
import { useTheme } from '../../../src/contexts/ThemeContext';
import { ArrowDown, AlertTriangle } from 'lucide-react';

export default function FunnelPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [funnel, setFunnel] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const siteId = localStorage.getItem('site_id') || 'demo-site';
    fetch(`/api/data?site_id=${siteId}`)
      .then(r => r.json())
      .then(data => {
        setFunnel(data.funnel || []);
        setLoading(false);
      });
  }, []);

  const card = isDark ? 'bg-[#111111] border border-[#1E1E1E]' : 'bg-white border border-gray-200 shadow-sm';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';

  if (loading) return <div className="p-6 text-gray-400">Loading...</div>;

  // Calculate percentages and drop-offs from real data
  const maxUsers = funnel[0]?.users || 1;
  const funnelSteps = funnel.map((step, i) => {
    const percentage = Math.round((step.users / maxUsers) * 100);
    const dropoff = i === 0 ? null : Math.round(((funnel[i-1].users - step.users) / funnel[i-1].users) * 100);
    const color = percentage > 60 ? '#10B981' : percentage > 30 ? '#F59E0B' : '#EF4444';
    const gravityScore = percentage > 80 ? 98 : percentage > 60 ? 76 : percentage > 30 ? 42 : 20;
    const gravityColor = gravityScore > 79 ? '#10B981' : gravityScore > 49 ? '#F59E0B' : '#EF4444';
    return { ...step, percentage, dropoff, color, gravityScore, gravityColor };
  });

  // Find biggest drop-off
  const biggestDrop = funnelSteps.reduce((worst, step) =>
    step.dropoff && step.dropoff > (worst.dropoff || 0) ? step : worst, funnelSteps[0]);

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>
      <h1 className="text-xl font-bold">Conversion Funnel Analysis</h1>

      <div className={`rounded-2xl p-6 ${card} space-y-2`}>
        {funnelSteps.map((s, i) => (
          <div key={s.page}>
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className={`text-xs ${muted} mr-2`}>Step {i + 1}</span>
                <span className="text-sm font-mono font-semibold">{s.page}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm font-bold">{s.users.toLocaleString()}</div>
                  <div className={`text-xs ${muted}`}>visitors</div>
                </div>
                {s.dropoff && (
                  <span className="text-xs text-red-400 font-semibold">-{s.dropoff}%</span>
                )}
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold"
                  style={{ background: `${s.gravityColor}20`, color: s.gravityColor, border: `1px solid ${s.gravityColor}40` }}>
                  Gravity Score: {s.gravityScore}
                </span>
              </div>
            </div>
            <div className={`h-12 rounded-xl overflow-hidden ${isDark ? 'bg-[#1A1A1A]' : 'bg-gray-100'}`}>
              <div className="h-full rounded-xl flex items-center px-4 text-white font-bold text-sm transition-all duration-700"
                style={{ width: `${s.percentage}%`, background: s.color }}>
                {s.percentage}%
              </div>
            </div>
            {i < funnelSteps.length - 1 && (
              <div className="flex justify-center py-2">
                <ArrowDown size={16} className={muted} />
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Drop-off map */}
      <div className={`rounded-2xl p-6 ${card}`}>
        <h3 className="font-semibold text-sm mb-6">Drop-off Map</h3>
        <div className="flex gap-8">
          <div className="flex-1 flex flex-col items-center">
            {funnelSteps.map((node, i) => (
              <div key={node.page} className="flex flex-col items-center w-full">
                <div className="w-44 rounded-xl p-4 text-center border"
                  style={{ borderColor: `${node.color}60`, background: `${node.color}10` }}>
                  <p className="font-mono font-semibold text-sm">{node.page}</p>
                  <p className={`text-xs mt-1 ${muted}`}>{node.users.toLocaleString()} visitors</p>
                </div>
                {node.dropoff && i < funnelSteps.length - 1 && (
                  <div className="flex flex-col items-center my-1">
                    <p className="text-xs text-red-400 font-medium">{node.dropoff}% exit</p>
                    <ArrowDown size={14} className={muted} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Biggest drop-off alert */}
      {biggestDrop?.dropoff && (
        <div className="rounded-2xl p-4 bg-red-950/30 border border-red-500/30 flex items-start gap-3">
          <AlertTriangle size={18} className="text-red-400 mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold text-red-400 text-sm mb-1">⚠️ Biggest Drop-off</p>
            <p className={`text-sm ${muted}`}>
              <span className="text-red-400 font-semibold">{biggestDrop.dropoff}% drop-off</span> detected at{' '}
              <code className="bg-red-900/30 px-1 py-0.5 rounded text-xs">{biggestDrop.page}</code>.
              Consider optimizing this page to improve conversions.
            </p>
          </div>
        </div>
      )}

      {/* Gravity score legend */}
      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4">Gravity Score Explained</h3>
        <div className="grid grid-cols-3 gap-3">
          {[
            { range: '80-100: Excellent', desc: 'Strong user retention, minimal friction', cls: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' },
            { range: '50-79: Good', desc: 'Acceptable flow, room for improvement', cls: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30' },
            { range: '0-49: Needs Work', desc: 'High drop-off, requires optimization', cls: 'bg-red-500/10 text-red-400 border-red-500/30' },
          ].map((g, i) => (
            <div key={i} className={`rounded-xl p-4 border ${g.cls}`}>
              <p className="text-sm font-semibold mb-1">{g.range}</p>
              <p className="text-xs opacity-80">{g.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}