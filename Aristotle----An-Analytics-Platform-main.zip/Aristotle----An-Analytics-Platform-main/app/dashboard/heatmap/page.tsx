'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { MousePointer, AlertCircle, ChevronDown, RefreshCw } from 'lucide-react';

interface ClickPoint {
  x: number;
  y: number;
}

interface PageData {
  page: string;
  clicks: ClickPoint[];
}

export default function HeatmapPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  const [siteId, setSiteId] = useState('');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [pages, setPages] = useState<string[]>([]);
  const [selectedPage, setSelectedPage] = useState('');
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [allClicks, setAllClicks] = useState<ClickPoint[]>([]);
  const [totalClicks, setTotalClicks] = useState(0);
  const [totalRageClicks, setTotalRageClicks] = useState(0);
  const [loading, setLoading] = useState(true);
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [lastUpdated, setLastUpdated] = useState('');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Read localStorage only on client
  useEffect(() => {
    setSiteId(localStorage.getItem('site_id') || '');
    setWebsiteUrl(localStorage.getItem('website_url') || '');
  }, []);

  const drawHeatmap = useCallback((clicks: ClickPoint[]) => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const W = container.offsetWidth;
    const H = container.offsetHeight;
    if (W === 0 || H === 0) return;

    canvas.width = W;
    canvas.height = H;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, W, H);

    if (clicks.length === 0) return;

    clicks.forEach(click => {
      // Clicks are recorded as absolute pixel coordinates on the original page
      // We scale them to fit the canvas container
      const cx = Math.min(click.x, W);  // keep within bounds
      const cy = Math.min(click.y, H);
      const radius = 50;

      const gradient = ctx.createRadialGradient(cx, cy, 0, cx, cy, radius);
      gradient.addColorStop(0, 'rgba(255, 40, 0, 0.85)');
      gradient.addColorStop(0.3, 'rgba(255, 100, 0, 0.5)');
      gradient.addColorStop(0.6, 'rgba(255, 180, 0, 0.2)');
      gradient.addColorStop(1, 'rgba(255, 200, 0, 0)');

      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();
    });
  }, []);

  // Redraw whenever clicks or iframe state changes
  useEffect(() => {
    // Small delay to ensure iframe and container are fully rendered
    const timer = setTimeout(() => drawHeatmap(allClicks), 200);
    return () => clearTimeout(timer);
  }, [allClicks, iframeLoaded, drawHeatmap]);

  const fetchData = useCallback(async (currentSiteId: string, currentPage: string) => {
    if (!currentSiteId) return;
    try {
      const res = await fetch(`/api/data?site_id=${currentSiteId}`);
      const json = await res.json();

      // Get unique pages
      const uniquePages: string[] = [];
      if (json.topPages) {
        json.topPages.forEach((p: any) => {
          if (!uniquePages.includes(p.page)) uniquePages.push(p.page);
        });
      }
      if (uniquePages.length === 0) uniquePages.push('/');
      setPages(uniquePages);

      const activePage = currentPage || uniquePages[0];
      if (!currentPage) setSelectedPage(uniquePages[0]);

      setTotalClicks((json.heatmapData?.length || 0) + (json.rageClicks || 0));
      setTotalRageClicks(json.rageClicks || 0);

      // Filter clicks for the active page
      const clicksForPage: ClickPoint[] = (json.heatmapData || []).filter(
  (c: any) => !c.page || c.page === activePage
);
      setAllClicks(clicksForPage);

      setLastUpdated(new Date().toLocaleTimeString('en-IN', {
        hour: '2-digit', minute: '2-digit', second: '2-digit'
      }));
    } catch (err) {
      console.error('Failed to fetch heatmap data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!siteId) return;
    fetchData(siteId, selectedPage);
    const interval = setInterval(() => fetchData(siteId, selectedPage), 5000);
    return () => clearInterval(interval);
  }, [siteId, selectedPage, fetchData]);

  const card = isDark ? 'bg-[#211507] border border-[#2A1C0A]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';

  // Build iframe URL — don't double-append if already in base URL
  const buildIframeUrl = () => {
    if (!websiteUrl) return '';
    if (!selectedPage) return websiteUrl;
    const base = websiteUrl.replace(/\/$/, '');
    if (base.endsWith(selectedPage)) return base;
    return `${base}${selectedPage}`;
  };
  const iframeUrl = buildIframeUrl();

  const handleIframeLoad = () => {
    setIframeLoaded(true);
    // Redraw after iframe fully loads
    setTimeout(() => drawHeatmap(allClicks), 300);
  };

  const handlePageSelect = (p: string) => {
    setSelectedPage(p);
    setDropdownOpen(false);
    setIframeLoaded(false);
    setAllClicks([]);
  };

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-xl font-bold">Click Heatmap</h1>
          {lastUpdated && <p className={`text-xs ${muted} mt-0.5`}>Last updated: {lastUpdated}</p>}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs text-green-500 font-medium">Live — updates every 5s</span>
          </div>

          <button onClick={() => fetchData(siteId, selectedPage)}
            className={`p-2 rounded-xl border transition-all ${isDark ? 'bg-[#2A1C0A] border-[#3A2910] text-gray-300 hover:bg-[#222]' : 'bg-white border-[#C8A97E]/40 text-gray-600 hover:bg-[#EDE8DF]'}`}>
            <RefreshCw size={14} />
          </button>

          <div className="relative">
            <button
              onClick={() => setDropdownOpen(v => !v)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium ${
                isDark ? 'bg-[#2A1C0A] border-[#3A2910] text-white hover:bg-[#222]' : 'bg-white border-[#C8A97E]/40 text-gray-700 hover:bg-[#EDE8DF]'
              }`}
            >
              Page: {selectedPage || '/'} <ChevronDown size={14} />
            </button>
            {dropdownOpen && (
              <div className={`absolute right-0 top-full mt-1 z-20 rounded-xl border py-1 min-w-[180px] shadow-xl ${
                isDark ? 'bg-[#2A1C0A] border-[#3A2910]' : 'bg-white border-[#C8A97E]/40'
              }`}>
                {pages.length === 0 ? (
                  <p className={`px-4 py-2 text-sm ${muted}`}>No pages tracked yet</p>
                ) : (
                  pages.map(p => (
                    <button key={p} onClick={() => handlePageSelect(p)}
                      className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                        selectedPage === p ? 'text-[#3B5E3A] font-medium' : isDark ? 'text-gray-300 hover:bg-[#222]' : 'text-gray-700 hover:bg-[#EDE8DF]'
                      }`}
                    >
                      {p}
                    </button>
                  ))
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Heatmap viewer */}
      <div className={`rounded-2xl overflow-hidden ${card}`}>
        {/* Browser bar */}
        {iframeUrl && (
          <div className={`flex items-center gap-2 px-4 py-2.5 border-b text-xs font-mono ${muted} ${isDark ? 'border-[#2A1C0A] bg-[#0D0D0D]' : 'border-gray-100 bg-gray-50'}`}>
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-400" />
              <div className="w-3 h-3 rounded-full bg-yellow-400" />
              <div className="w-3 h-3 rounded-full bg-green-400" />
            </div>
            <span className="ml-2 truncate">{iframeUrl}</span>
          </div>
        )}

        <div
          ref={containerRef}
          className="relative w-full"
          style={{ height: '520px', background: '#ffffff' }}
          onClick={() => setDropdownOpen(false)}
        >
          {loading ? (
            <div className="flex items-center justify-center h-full gap-3 bg-white">
              <div className="w-5 h-5 border-2 border-[#A67C52] border-t-transparent rounded-full animate-spin" />
              <span className="text-sm text-gray-500">Loading heatmap...</span>
            </div>
          ) : !iframeUrl ? (
            <>
              <div className="absolute inset-0 bg-white" style={{
                backgroundImage: `linear-gradient(#E5E7EB 1px, transparent 1px), linear-gradient(90deg, #E5E7EB 1px, transparent 1px)`,
                backgroundSize: '40px 40px',
              }} />
              {allClicks.length === 0 && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <p className="text-sm text-gray-500 text-center px-8">
                    No click data yet for {selectedPage || '/'}.<br />
                    Go to your website and start clicking!
                  </p>
                </div>
              )}
              <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
            </>
          ) : (
            <>
              {/* White background so iframe content looks clean */}
              <div className="absolute inset-0 bg-white" />
              <iframe
                key={iframeUrl}
                src={iframeUrl}
                className="absolute inset-0 w-full h-full border-0"
                style={{ pointerEvents: 'none', background: '#ffffff' }}
                onLoad={handleIframeLoad}
                title="Website Preview"
              />
              {!iframeLoaded && (
                <div className="absolute inset-0 flex items-center justify-center gap-3 bg-white">
                  <div className="w-5 h-5 border-2 border-[#A67C52] border-t-transparent rounded-full animate-spin" />
                  <span className="text-sm text-gray-500">Loading website preview...</span>
                </div>
              )}
              {allClicks.length === 0 && iframeLoaded && (
                <div className="absolute bottom-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-xl text-xs font-medium bg-black/70 text-white whitespace-nowrap">
                  No clicks recorded on this page yet — go click on your site!
                </div>
              )}
              {/* Heatmap canvas on top of iframe */}
              <canvas
                ref={canvasRef}
                className="absolute inset-0 w-full h-full pointer-events-none"
                style={{ mixBlendMode: 'multiply' }}
              />
            </>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className={`rounded-2xl p-5 ${card}`}>
          <div className={`mb-2 ${muted}`}><MousePointer size={18} /></div>
          <div className="text-3xl font-bold mb-1">{totalClicks.toLocaleString()}</div>
          <div className={`text-xs ${muted}`}>Total Clicks</div>
        </div>
        <div className="rounded-2xl p-5 bg-red-950/40 border border-red-500/40">
          <div className="mb-2 text-red-400"><AlertCircle size={18} /></div>
          <div className="text-3xl font-bold text-red-400 mb-1">{totalRageClicks.toLocaleString()}</div>
          <div className="text-xs text-red-400/70">Rage Clicks</div>
        </div>
      </div>

      {/* Color scale */}
      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="text-sm font-semibold mb-3">Color Scale</h3>
        <div className="flex items-center gap-3">
          <span className={`text-xs ${muted}`}>Cold (few clicks)</span>
          <div className="flex-1 h-4 rounded-full" style={{ background: 'linear-gradient(to right, #3B82F6, #8B5CF6, #EC4899, #EF4444, #DC2626)' }} />
          <span className={`text-xs ${muted}`}>Hot (many clicks)</span>
        </div>
      </div>
    </div>
  );
}
