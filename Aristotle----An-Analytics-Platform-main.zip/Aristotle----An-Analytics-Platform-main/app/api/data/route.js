import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function GET(request) {
    const { searchParams } = new URL(request.url);
    const siteId = searchParams.get('site_id') || 'demo-site';

    const todayViews = await pool.query(
        `SELECT COUNT(*) as count FROM events WHERE site_id=$1 AND type='pageview' AND created_at > NOW() - interval '1 day'`, [siteId]
    );

    const weeklyTraffic = await pool.query(
        `SELECT DATE(created_at) as date, COUNT(*) as views FROM events WHERE site_id=$1 AND type='pageview' AND created_at > NOW() - interval '7 days' GROUP BY DATE(created_at) ORDER BY date`, [siteId]
    );

    const topPages = await pool.query(
        `SELECT page, COUNT(*) as views FROM events WHERE site_id=$1 AND type='pageview' GROUP BY page ORDER BY views DESC LIMIT 5`, [siteId]
    );

    const rageClicks = await pool.query(
        `SELECT COUNT(*) as count FROM events WHERE site_id=$1 AND type='rage_click'`, [siteId]
    );

    const heatmapData = await pool.query(
        `SELECT x, y, page FROM events WHERE site_id=$1 AND type IN ('click','rage_click') AND x IS NOT NULL`, [siteId]
    );

    // Live users — pageviews in last 5 minutes
    const liveUsers = await pool.query(
        `SELECT COUNT(DISTINCT COALESCE(city, 'Unknown')) as count FROM events 
         WHERE site_id=$1 AND type='pageview' AND created_at > NOW() - interval '5 minutes'`, [siteId]
    );

    // Live user locations — recent pageviews with location data
    const liveLocations = await pool.query(
        `SELECT city, country, country_code, lat, lon, page, created_at,
                COUNT(*) as user_count
         FROM events 
         WHERE site_id=$1 
           AND type='pageview' 
           AND created_at > NOW() - interval '30 minutes'
           AND lat IS NOT NULL 
           AND lon IS NOT NULL
         GROUP BY city, country, country_code, lat, lon, page, created_at
         ORDER BY created_at DESC
         LIMIT 50`, [siteId]
    );

    // Top countries
    const topCountries = await pool.query(
        `SELECT country, country_code, COUNT(*) as visits
         FROM events
         WHERE site_id=$1 AND type='pageview' AND country IS NOT NULL
         GROUP BY country, country_code
         ORDER BY visits DESC
         LIMIT 5`, [siteId]
    );

    // Recent activity feed
    const recentActivity = await pool.query(
        `SELECT type, page, city, country, country_code, created_at
         FROM events
         WHERE site_id=$1 AND created_at > NOW() - interval '30 minutes'
         ORDER BY created_at DESC
         LIMIT 20`, [siteId]
    );

    // Dynamic funnel
    const funnelPagesResult = await pool.query(
        `SELECT DISTINCT page FROM events WHERE site_id=$1 AND type='pageview' ORDER BY page LIMIT 5`, [siteId]
    );
    const funnelPageList = funnelPagesResult.rows.map(r => r.page);

    const funnelCounts = await Promise.all(
        funnelPageList.map(page =>
            pool.query(
                `SELECT COUNT(*) as users FROM events WHERE site_id=$1 AND page=$2 AND type='pageview'`, [siteId, page]
            )
        )
    );

    const todayCount = parseInt(todayViews.rows[0].count);
    const avgViews = weeklyTraffic.rows.reduce((s, r) => s + parseInt(r.views), 0) / 7;

    let aiInsight = null;
    if (todayCount > avgViews * 1.5) {
        aiInsight = `Traffic is ${Math.round((todayCount / avgViews) * 100)}% above your daily average. Consider checking recent referral sources.`;
    }

    return Response.json({
        siteId,
        todayViews: todayCount,
        rageClicks: parseInt(rageClicks.rows[0].count),
        weeklyTraffic: weeklyTraffic.rows,
        topPages: topPages.rows,
        heatmapData: heatmapData.rows,
        liveUserCount: parseInt(liveUsers.rows[0].count) || 0,
        liveLocations: liveLocations.rows,
        topCountries: topCountries.rows,
        recentActivity: recentActivity.rows,
        funnel: funnelPageList.map((page, i) => ({
            page,
            users: parseInt(funnelCounts[i].rows[0].users)
        })),
        aiInsight
    }, {
        headers: { 'Access-Control-Allow-Origin': '*' }
    });
}
