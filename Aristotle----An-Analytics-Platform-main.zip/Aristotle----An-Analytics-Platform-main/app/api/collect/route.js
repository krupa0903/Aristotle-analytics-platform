import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function getLocation(ip) {
    try {
        // Use ip-api.com free tier (no key needed, 1000 req/min)
        const res = await fetch(`http://ip-api.com/json/${ip}?fields=city,country,countryCode,lat,lon,status`);
        const data = await res.json();
        if (data.status === 'success') {
            return {
                city: data.city || null,
                country: data.country || null,
                country_code: data.countryCode || null,
                lat: data.lat || null,
                lon: data.lon || null,
            };
        }
    } catch (e) {
        // Silently fail — location is optional
    }
    return { city: null, country: null, country_code: null, lat: null, lon: null };
}

export async function POST(request) {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
    };

    try {
        const body = await request.json();
        const { site_id, type, page, x, y, referrer } = body;

        // Get IP from request headers
        const forwarded = request.headers.get('x-forwarded-for');
        const ip = forwarded ? forwarded.split(',')[0].trim() : request.headers.get('x-real-ip');

        // Get location from IP (skip for localhost)
        let location = { city: null, country: null, country_code: null, lat: null, lon: null };
        if (ip && ip !== '127.0.0.1' && ip !== '::1' && !ip.startsWith('192.168') && !ip.startsWith('10.')) {
            location = await getLocation(ip);
        } else {
            // For localhost testing, use a default location (Mumbai)
            location = { city: 'Mumbai', country: 'India', country_code: 'IN', lat: 19.0760, lon: 72.8777 };
        }

        await pool.query(
            `INSERT INTO events (site_id, type, page, x, y, referrer, city, country, country_code, lat, lon) 
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
            [site_id, type, page, x || null, y || null, referrer || null,
             location.city, location.country, location.country_code, location.lat, location.lon]
        );

        return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
    } catch (err) {
        return new Response(JSON.stringify({ error: err.message }), { status: 500, headers });
    }
}

export async function OPTIONS(request) {
    const origin = request.headers.get('origin') || '*';
    return new Response(null, {
        status: 204,
        headers: {
            'Access-Control-Allow-Origin': origin,
            'Access-Control-Allow-Methods': 'POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type',
            'Access-Control-Allow-Credentials': 'true',
        },
    });
}