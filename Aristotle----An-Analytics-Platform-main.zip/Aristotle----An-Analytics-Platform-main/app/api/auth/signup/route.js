import { Pool } from 'pg';
import crypto from 'crypto';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function POST(request) {
    const headers = { 'Access-Control-Allow-Origin': '*' };
    try {
        const { name, email, password, website_url, website_name } = await request.json();

        // Check if email already exists
        const existing = await pool.query(
            'SELECT id FROM users WHERE email=$1', [email]
        );
        if (existing.rows.length > 0) {
            return Response.json({ error: 'Email already registered' }, { status: 400, headers });
        }

        // Generate unique IDs
        const id = crypto.randomUUID();
        const site_id = crypto.randomBytes(4).toString('hex');
        const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

        // Save to database — now includes website_name
        await pool.query(
            `INSERT INTO users (id, name, email, password, website_url, website_name, site_id) 
       VALUES ($1, $2, $3, $4, $5, $6, $7)`, [id, name, email, hashedPassword, website_url, website_name, site_id]
        );

        // Return everything frontend needs
        return Response.json({
            ok: true,
            site_id,
            name,
            email,
            website_url,
            website_name // ← was missing before
        }, { status: 200, headers });

    } catch (err) {
        return Response.json({ error: err.message }, { status: 500, headers });
    }
}