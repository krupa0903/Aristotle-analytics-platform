'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Mail, Lock, User, Globe, Eye, EyeOff, Sun, Moon } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

export default function SignUpPage() {
  const router = useRouter();
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [form, setForm] = useState({
    name: '',
    email: '',
    website_name: '',
    website_url: '',
    password: '',
    confirm_password: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirm_password) {
      alert('Passwords do not match');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          email: form.email,
          password: form.password,
          website_name: form.website_name,
          website_url: form.website_url
        })
      });
      const data = await res.json();
      if (data.error) {
        alert(data.error);
        setLoading(false);
        return;
      }
      localStorage.setItem('site_id', data.site_id);
      localStorage.setItem('user_name', data.name);
      localStorage.setItem('user_email', data.email);
      localStorage.setItem('website_url', data.website_url);
      localStorage.setItem('website_name', data.website_name);
      router.push('/dashboard');
    } catch {
      alert('Something went wrong');
      setLoading(false);
    }
  };

  const bg = isDark ? 'bg-[#0D0D0D]' : 'bg-[#F5F0E8]';
  const card = isDark
    ? 'bg-[#141414] border border-[#3A2910]'
    : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const inputCls = isDark
    ? 'bg-[#1E1E1E] border border-[#3A2910] text-white placeholder-gray-600 focus:border-[#7C3AED]'
    : 'bg-[#EDE8DF] border border-[#C8A97E]/40 text-gray-900 placeholder-gray-400 focus:border-[#7C3AED]';
  const labelCls = isDark ? 'text-gray-300' : 'text-gray-700';
  const muted = isDark ? 'text-gray-500' : 'text-gray-500';
  const toggleBtn = isDark
    ? 'bg-[#1E1E1E] border border-[#3A2910] text-gray-400 hover:bg-[#2A2A2A]'
    : 'bg-white border border-[#C8A97E]/40 text-gray-600 hover:bg-[#EDE8DF] shadow-sm';

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-4 ${bg}`}>

      {/* Theme Toggle */}
      <button
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        className={`fixed top-5 right-5 p-2.5 rounded-full transition-all ${toggleBtn}`}
      >
        {isDark ? <Sun size={18} /> : <Moon size={18} />}
      </button>

      <div className="w-full max-w-md">

        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="flex items-center gap-2 mb-1">
            <div className="w-7 h-7 bg-[#5A3E1B] rounded-lg flex items-center justify-center">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M7 1L13 7L7 13L1 7L7 1Z" fill="white" />
              </svg>
            </div>
            <span className={`text-lg font-bold ${isDark ? 'text-white' : 'text-gray-900'}`}>
              Aristotle
            </span>
          </div>
          <p className={`text-sm ${muted}`}>Create your account</p>
        </div>

        {/* Card */}
        <div className={`rounded-2xl p-8 ${card}`}>
          <form onSubmit={handleSubmit} className="space-y-4">

            {/* Full Name */}
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Full Name</label>
              <div className="relative">
                <User size={15} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input
                  type="text"
                  placeholder="John Doe"
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  required
                  className={`w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-colors ${inputCls}`}
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Email</label>
              <div className="relative">
                <Mail size={15} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))}
                  required
                  className={`w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-colors ${inputCls}`}
                />
              </div>
            </div>

            {/* Website Name */}
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Website Name</label>
              <div className="relative">
                <Globe size={15} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input
                  type="text"
                  placeholder="My Awesome Site"
                  value={form.website_name}
                  onChange={e => setForm(f => ({ ...f, website_name: e.target.value }))}
                  required
                  className={`w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-colors ${inputCls}`}
                />
              </div>
            </div>

            {/* Website URL */}
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Website URL</label>
              <div className="relative">
                <Globe size={15} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input
                  type="url"
                  placeholder="https://example.com"
                  value={form.website_url}
                  onChange={e => setForm(f => ({ ...f, website_url: e.target.value }))}
                  required
                  className={`w-full pl-10 pr-4 py-3 rounded-xl text-sm outline-none transition-colors ${inputCls}`}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Password</label>
              <div className="relative">
                <Lock size={15} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input
                  type={showPass ? 'text' : 'password'}
                  placeholder="Create a password"
                  value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                  required
                  minLength={8}
                  className={`w-full pl-10 pr-10 py-3 rounded-xl text-sm outline-none transition-colors ${inputCls}`}
                />
                <button
                  type="button"
                  onClick={() => setShowPass(v => !v)}
                  className={`absolute right-3.5 top-1/2 -translate-y-1/2 ${muted}`}
                >
                  {showPass ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Confirm Password</label>
              <div className="relative">
                <Lock size={15} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input
                  type={showConfirm ? 'text' : 'password'}
                  placeholder="Confirm your password"
                  value={form.confirm_password}
                  onChange={e => setForm(f => ({ ...f, confirm_password: e.target.value }))}
                  required
                  className={`w-full pl-10 pr-10 py-3 rounded-xl text-sm outline-none transition-colors ${inputCls}`}
                />
                <button
                  type="button"
                  onClick={() => setShowConfirm(v => !v)}
                  className={`absolute right-3.5 top-1/2 -translate-y-1/2 ${muted}`}
                >
                  {showConfirm ? <EyeOff size={15} /> : <Eye size={15} />}
                </button>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-[#5A3E1B] hover:bg-[#3B5E3A] text-white rounded-xl font-semibold text-sm transition-all disabled:opacity-70 mt-2"
            >
              {loading ? 'Creating account...' : 'Sign Up'}
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3 my-2">
              <div className={`flex-1 h-px ${isDark ? 'bg-[#2A2A2A]' : 'bg-gray-200'}`} />
              <span className={`text-xs ${muted}`}>or continue with</span>
              <div className={`flex-1 h-px ${isDark ? 'bg-[#2A2A2A]' : 'bg-gray-200'}`} />
            </div>

            {/* Google Button */}
            <button
              type="button"
              className={`w-full py-3 rounded-xl text-sm font-medium flex items-center justify-center gap-2 border transition-all ${
                isDark
                  ? 'border-[#3A2910] text-gray-300 hover:bg-[#1E1E1E]'
                  : 'border-[#C8A97E]/40 text-gray-700 hover:bg-[#EDE8DF]'
              }`}
            >
              <svg width="18" height="18" viewBox="0 0 18 18">
                <path d="M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
                <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z" fill="#34A853"/>
                <path d="M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
                <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
              </svg>
              Sign up with Google
            </button>

          </form>

          <p className={`text-center text-sm mt-5 ${muted}`}>
            Already have an account?{' '}
            <Link href="/auth/signin" className="text-[#3B5E3A] font-medium hover:underline">
              Sign In
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}