(function() {
    var script = document.currentScript || (function() {
        var scripts = document.getElementsByTagName('script');
        return scripts[scripts.length - 1];
    })();
    var API_URL = script.getAttribute('data-api') || 'https://your-deployed-url.vercel.app';
    var SITE_ID = script.getAttribute('data-site') || 'demo-site';

    // ─── BOT DETECTION ────────────────────────────────────────────────────────
    var botPattern =
        /bot|crawl|spider|slurp|facebookexternalhit|whatsapp|preview|lighthouse|pagespeed|chrome-lighthouse/i;

    if (botPattern.test(navigator.userAgent)) {
        return;
    }

    // ─── HELPERS ──────────────────────────────────────────────────────────────

    function send(type, extra) {
        var payload = Object.assign({
                site_id: SITE_ID,
                type: type,
                page: window.location.pathname,
                referrer: document.referrer || null,
            },
            extra || {}
        );

        var url = API_URL + "/api/collect";
        var body = JSON.stringify(payload);

        // Use fetch with credentials: omit to avoid CORS preflight issues
        if (typeof fetch !== 'undefined') {
            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: body,
                credentials: 'omit',  // ← key fix: no cookies, no CORS conflict
                keepalive: true       // fire-and-forget even on page unload
            }).catch(function() {}); // silent fail
        } else {
            // Fallback for old browsers
            var xhr = new XMLHttpRequest();
            xhr.open("POST", url, true);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.withCredentials = false; // ← no credentials
            xhr.send(body);
        }
    }

    // ─── PAGEVIEW ─────────────────────────────────────────────────────────────
    send("pageview");

    // ─── CLICK TRACKING ───────────────────────────────────────────────────────
    var rageState = {
        x: null,
        y: null,
        count: 0,
        timer: null,
    };

    var RAGE_THRESHOLD = 3;
    var RAGE_WINDOW_MS = 2000;
    var RAGE_RADIUS = 30;

    document.addEventListener(
        "click",
        function(e) {
            var x = Math.round(e.pageX);
            var y = Math.round(e.pageY);

            var dx = Math.abs(x - rageState.x);
            var dy = Math.abs(y - rageState.y);
            var isNearby = dx < RAGE_RADIUS && dy < RAGE_RADIUS;

            if (isNearby && rageState.count > 0) {
                rageState.count++;
            } else {
                rageState.count = 1;
                rageState.x = x;
                rageState.y = y;
            }

            clearTimeout(rageState.timer);
            rageState.timer = setTimeout(function() {
                rageState.count = 0;
            }, RAGE_WINDOW_MS);

            if (rageState.count === RAGE_THRESHOLD) {
                send("rage_click", { x: x, y: y });
                rageState.count = 0;
            }

            send("click", { x: x, y: y });
        }, { passive: true }
    );

    // ─── SINGLE-PAGE APP SUPPORT ──────────────────────────────────────────────
    var _pushState = history.pushState;
    history.pushState = function() {
        _pushState.apply(this, arguments);
        send("pageview");
    };

    window.addEventListener("popstate", function() {
        send("pageview");
    });
})();