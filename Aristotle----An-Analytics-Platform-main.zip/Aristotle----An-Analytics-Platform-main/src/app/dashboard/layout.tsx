'use client';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { Sun, Moon, Settings, User } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

const navItems = [
  { label: 'Dashboard', href: '/dashboard' },
  { label: 'Heatmap', href: '/dashboard/heatmap' },
  { label: 'Funnel', href: '/dashboard/funnel' },
  { label: 'Live Users', href: '/dashboard/live' },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  const navBg = isDark ? 'bg-[#1A1108] border-[#2A1C0A]' : 'bg-[#F5F0E8] border-[#C8A97E]/40';
  const muted = isDark ? 'text-gray-500' : 'text-gray-500';
  const pageBg = isDark ? 'bg-[#1A1108] text-[#F5F0E8]' : 'bg-[#EDE8DF] text-[#2C1A0E]';

  return (
    <div className={`min-h-screen transition-colors duration-300 ${pageBg}`}>
      <nav className={`fixed top-0 left-0 right-0 z-50 border-b h-14 flex items-center px-6 ${navBg}`}>

        <Link href="/dashboard" className="flex items-center gap-2 mr-8">
          <div className="w-7 h-7 bg-[#5A3E1B] rounded-lg flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="5" stroke="#C8A97E" strokeWidth="1.2" fill="none"/>
              <line x1="7" y1="2" x2="7" y2="12" stroke="#C8A97E" strokeWidth="1"/>
              <line x1="2" y1="7" x2="12" y2="7" stroke="#C8A97E" strokeWidth="1"/>
              <circle cx="7" cy="7" r="1.5" fill="#A67C52"/>
            </svg>
          </div>
          <span className="font-bold text-base" style={{ fontFamily: "'DM Serif Display', serif" }}>
            Aristotle
          </span>
        </Link>

        <div className="flex items-center gap-1 flex-1 justify-center">
          {navItems.map(item => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  active
                    ? 'bg-[#5A3E1B] text-[#C8A97E]'
                    : `${muted} ${isDark ? 'hover:bg-[#2A1C0A] hover:text-[#F5F0E8]' : 'hover:bg-[#C8A97E]/20 hover:text-[#2C1A0E]'}`
                }`}>
                {item.label}
              </Link>
            );
          })}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setTheme(isDark ? 'light' : 'dark')}
            className={`p-2 rounded-lg transition-all ${isDark ? 'hover:bg-[#2A1C0A] text-gray-400' : 'hover:bg-[#C8A97E]/20 text-gray-500'}`}>
            {isDark ? <Sun size={17} /> : <Moon size={17} />}
          </button>
          <Link
            href="/dashboard/settings"
            className={`p-2 rounded-lg transition-all ${isDark ? 'hover:bg-[#2A1C0A] text-gray-400' : 'hover:bg-[#C8A97E]/20 text-gray-500'}`}>
            <Settings size={17} />
          </Link>
          <button
            onClick={() => router.push('/')}
            className="w-8 h-8 bg-[#5A3E1B] rounded-full flex items-center justify-center hover:bg-[#3B5E3A] transition-all">
            <User size={15} className="text-white" />
          </button>
        </div>

      </nav>
      <main className="pt-14 min-h-screen">{children}</main>
    </div>
  );
}