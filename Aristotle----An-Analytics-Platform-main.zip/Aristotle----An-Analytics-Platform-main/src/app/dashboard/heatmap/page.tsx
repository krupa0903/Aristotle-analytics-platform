'use client';
import { useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { MousePointer, AlertCircle, ChevronDown } from 'lucide-react';

const pages = ['/home', '/pricing', '/features', '/about', '/contact'];
const heatmapBlobs: Record<string, { x: string; y: string; size: string; intensity: string }[]> = {
  '/home': [
    { x: '25%', y: '35%', size: '120px', intensity: '0.9' },
    { x: '50%', y: '55%', size: '90px', intensity: '0.7' },
    { x: '65%', y: '70%', size: '100px', intensity: '0.75' },
    { x: '80%', y: '25%', size: '55px', intensity: '0.4' },
  ],
  '/pricing': [
    { x: '50%', y: '30%', size: '140px', intensity: '0.95' },
    { x: '30%', y: '60%', size: '80px', intensity: '0.6' },
    { x: '70%', y: '50%', size: '70px', intensity: '0.55' },
  ],
  '/features': [
    { x: '20%', y: '40%', size: '100px', intensity: '0.8' },
    { x: '60%', y: '30%', size: '110px', intensity: '0.85' },
    { x: '40%', y: '65%', size: '85px', intensity: '0.65' },
  ],
  '/about': [
    { x: '45%', y: '45%', size: '130px', intensity: '0.9' },
    { x: '25%', y: '70%', size: '70px', intensity: '0.5' },
  ],
  '/contact': [
    { x: '50%', y: '40%', size: '110px', intensity: '0.88' },
    { x: '35%', y: '65%', size: '90px', intensity: '0.7' },
    { x: '65%', y: '30%', size: '65px', intensity: '0.5' },
  ],
};

export default function HeatmapPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [selectedPage, setSelectedPage] = useState('/home');
  const [dropdownOpen, setDropdownOpen] = useState(false);

  const card = isDark ? 'bg-[#211507] border border-[#3A2910]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-[#3B5E3A]' : 'text-[#5A3E1B]/70';
  const blobs = heatmapBlobs[selectedPage] ?? heatmapBlobs['/home'];

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold" style={{ fontFamily: "'DM Serif Display', serif" }}>Click Heatmap</h1>
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(v => !v)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border text-sm font-medium ${
              isDark ? 'bg-[#2A1C0A] border-[#3A2910] text-[#F5F0E8] hover:bg-[#3A2910]' : 'bg-white border-[#C8A97E]/40 text-[#2C1A0E] hover:bg-[#EDE8DF]'
            }`}
          >
            Page: {selectedPage} <ChevronDown size={14} />
          </button>
          {dropdownOpen && (
            <div className={`absolute right-0 top-full mt-1 z-20 rounded-xl border py-1 min-w-[140px] shadow-xl ${
              isDark ? 'bg-[#2A1C0A] border-[#3A2910]' : 'bg-white border-[#C8A97E]/40'
            }`}>
              {pages.map(p => (
                <button key={p} onClick={() => { setSelectedPage(p); setDropdownOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-sm transition-colors ${
                    selectedPage === p ? 'text-[#3B5E3A] font-medium' : isDark ? 'text-[#F5F0E8] hover:bg-[#3A2910]' : 'text-[#2C1A0E] hover:bg-[#EDE8DF]'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className={`rounded-2xl overflow-hidden ${card}`}>
        <div className="relative w-full" style={{ height: '420px', background: isDark ? '#1A1108' : '#F5F0E8' }} onClick={() => setDropdownOpen(false)}>
          <div className="absolute inset-0 opacity-20" style={{
            backgroundImage: `linear-gradient(${isDark ? '#3A2910' : '#C8A97E'} 1px, transparent 1px), linear-gradient(90deg, ${isDark ? '#3A2910' : '#C8A97E'} 1px, transparent 1px)`,
            backgroundSize: '40px 40px',
          }} />
          {blobs.map((blob, i) => (
            <div key={`${selectedPage}-${i}`} className="absolute heat-blob" style={{
              left: blob.x, top: blob.y, width: blob.size, height: blob.size,
              transform: 'translate(-50%, -50%)',
              background: `radial-gradient(circle, rgba(255,60,0,${blob.intensity}) 0%, rgba(255,120,0,${parseFloat(blob.intensity) * 0.6}) 40%, transparent 70%)`,
              filter: 'blur(8px)', animationDelay: `${i * 0.3}s`,
            }} />
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className={`rounded-2xl p-5 ${card}`}>
          <div className={`mb-2 text-[#3B5E3A]`}><MousePointer size={18} /></div>
          <div className="text-3xl font-bold mb-1">8,421</div>
          <div className={`text-xs ${muted}`}>Total Clicks</div>
        </div>
        <div className="rounded-2xl p-5 bg-red-950/40 border border-red-500/40">
          <div className="mb-2 text-red-400"><AlertCircle size={18} /></div>
          <div className="text-3xl font-bold text-red-400 mb-1">127</div>
          <div className="text-xs text-red-400/70">Rage Clicks</div>
        </div>
      </div>

      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="text-sm font-semibold mb-3" style={{ fontFamily: "'DM Serif Display', serif" }}>Color Scale</h3>
        <div className="flex items-center gap-3">
          <span className={`text-xs ${muted}`}>Cold</span>
          <div className="flex-1 h-4 rounded-full" style={{ background: 'linear-gradient(to right, #2C3E50, #3B5E3A, #A67C52, #C8A97E, #D85A30)' }} />
          <span className={`text-xs ${muted}`}>Hot</span>
        </div>
      </div>
    </div>
  );
}