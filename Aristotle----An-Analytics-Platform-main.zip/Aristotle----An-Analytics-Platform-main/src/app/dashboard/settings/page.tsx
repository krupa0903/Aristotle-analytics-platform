'use client';
import { useState, useEffect } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import type { Theme } from '@/contexts/ThemeContext';

const sections = ['General', 'Tracking Script', 'Notifications', 'Privacy', 'Account', 'Danger Zone'];

export default function SettingsPage() {
  const { resolvedTheme, theme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [active, setActive] = useState('General');
  const [siteName, setSiteName] = useState('');
  const [siteUrl, setSiteUrl] = useState('');
  const [timezone, setTimezone] = useState('UTC');
  const [saved, setSaved] = useState(false);
  const [siteId, setSiteId] = useState('');
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setSiteId(localStorage.getItem('site_id') || '');
    setUserName(localStorage.getItem('user_name') || '');
    setUserEmail(localStorage.getItem('user_email') || '');
    setSiteUrl(localStorage.getItem('website_url') || '');
    setSiteName(localStorage.getItem('website_name') || '');
  }, []);

  const trackingScript = `<script src="http://localhost:3000/tracker.js" data-site="${siteId}" data-api="http://localhost:3000"></script>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(trackingScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const card = isDark ? 'bg-[#211507] border border-[#2A1C0A]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const inputCls = isDark
    ? 'bg-[#2A1C0A] border-[#3A2910] text-white focus:border-[#7C3AED]'
    : 'bg-[#EDE8DF] border-[#C8A97E]/40 text-gray-900 focus:border-[#7C3AED]';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';
  const labelCls = isDark ? 'text-gray-300' : 'text-gray-700';

  const handleSave = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <div className="p-6 max-w-[1200px] mx-auto" style={{ animation: 'fadeIn 0.3s ease' }}>
      <div className="flex gap-6">
        {/* Sidebar */}
        <div className={`w-48 rounded-2xl p-2 h-fit ${card}`}>
          {sections.map(s => (
            <button key={s} onClick={() => setActive(s)}
              className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium transition-all ${
                active === s ? 'bg-[#5A3E1B] text-white' : `${muted} ${isDark ? 'hover:bg-[#2A1C0A] hover:text-white' : 'hover:bg-gray-100 hover:text-gray-900'}`
              }`}
            >
              {s}
            </button>
          ))}
        </div>

        {/* Content panel */}
        <div className={`flex-1 rounded-2xl p-6 ${card}`}>
          {active === 'General' && (
            <div className="space-y-6">
              <h2 className="text-lg font-bold">General Settings</h2>
              <div>
                <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Site Name</label>
                <input type="text" value={siteName} onChange={e => setSiteName(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none transition-colors ${inputCls}`} />
              </div>
              <div>
                <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Site URL</label>
                <input type="url" value={siteUrl} onChange={e => setSiteUrl(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none transition-colors ${inputCls}`} />
              </div>
              <div>
                <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Timezone</label>
                <select value={timezone} onChange={e => setTimezone(e.target.value)}
                  className={`w-full px-4 py-2.5 rounded-xl border text-sm outline-none transition-colors ${inputCls}`}>
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">America/New_York</option>
                  <option value="Europe/London">Europe/London</option>
                  <option value="Asia/Tokyo">Asia/Tokyo</option>
                  <option value="Asia/Kolkata">Asia/Kolkata</option>
                  <option value="Australia/Sydney">Australia/Sydney</option>
                </select>
              </div>
              <div>
                <label className={`text-sm font-medium mb-3 block ${labelCls}`}>Theme</label>
                <div className="flex gap-2">
                  {(['light', 'dark', 'system'] as Theme[]).map(t => (
                    <button key={t} onClick={() => setTheme(t)}
                      className={`px-5 py-2 rounded-xl text-sm font-medium capitalize transition-all ${
                        theme === t ? 'bg-[#5A3E1B] text-white'
                          : isDark ? 'bg-[#2A1C0A] text-gray-400 hover:text-white border border-[#3A2910]'
                          : 'bg-gray-100 text-gray-600 hover:text-gray-900 border border-[#C8A97E]/40'
                      }`}
                    >{t}</button>
                  ))}
                </div>
              </div>
              <button onClick={handleSave}
                className={`px-6 py-2.5 rounded-xl font-semibold text-sm transition-all ${saved ? 'bg-emerald-500 text-white' : 'bg-[#5A3E1B] hover:bg-[#3B5E3A] text-white'}`}>
                {saved ? '✓ Saved!' : 'Save Changes'}
              </button>
            </div>
          )}

          {active === 'Tracking Script' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Tracking Script</h2>
              <p className={`text-sm ${muted}`}>Add this script to your website&apos;s &lt;head&gt; tag to start tracking.</p>

              {/* Site ID display */}
              <div>
                <label className={`text-xs font-medium mb-1.5 block ${muted}`}>YOUR SITE ID</label>
                <div className={`rounded-xl px-4 py-3 font-mono text-sm border flex items-center justify-between ${isDark ? 'bg-[#0D0D0D] text-white border-[#3A2910]' : 'bg-[#EDE8DF] text-gray-900 border-[#C8A97E]/40'}`}>
                  <span>{siteId || 'Not found — please sign in again'}</span>
                </div>
              </div>

              {/* Tracking script */}
              <div>
                <label className={`text-xs font-medium mb-1.5 block ${muted}`}>TRACKING SCRIPT</label>
                <div className={`rounded-xl p-4 font-mono text-xs leading-relaxed border ${isDark ? 'bg-[#0D0D0D] text-[#3B5E3A] border-[#3A2910]' : 'bg-[#EDE8DF] text-emerald-600 border-[#C8A97E]/40'}`}>
                  {trackingScript}
                </div>
              </div>

              <button onClick={handleCopy}
                className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${copied ? 'bg-emerald-500 text-white' : 'bg-[#5A3E1B] hover:bg-[#3B5E3A] text-white'}`}>
                {copied ? '✓ Copied!' : 'Copy Script'}
              </button>

              <p className={`text-xs ${muted}`}>Script size: &lt;5KB • Zero performance impact</p>
            </div>
          )}

          {active === 'Notifications' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Notifications</h2>
              {['AI Anomaly Alerts', 'Weekly Reports', 'Traffic Spikes', 'Rage Click Alerts'].map((item, i) => (
                <div key={i} className={`flex items-center justify-between py-3 border-b last:border-0 ${isDark ? 'border-[#2A1C0A]' : 'border-gray-100'}`}>
                  <span className="text-sm">{item}</span>
                  <div className={`w-10 h-6 rounded-full flex items-center transition-all cursor-pointer ${i % 2 === 0 ? 'bg-[#5A3E1B] justify-end' : isDark ? 'bg-[#2A2A2A] justify-start' : 'bg-gray-200 justify-start'} px-1`}>
                    <div className="w-4 h-4 rounded-full bg-white shadow-sm" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {active === 'Privacy' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Privacy Settings</h2>
              {['No Cookies', 'No IP Storage', 'GDPR Compliant', 'Under 5KB Script', 'No Cross-Site Tracking'].map((item, i) => (
                <div key={i} className="flex items-center gap-3 py-2">
                  <div className="w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center shrink-0">
                    <span className="text-white text-xs">✓</span>
                  </div>
                  <span className="text-sm">{item}</span>
                  <span className="ml-auto text-xs text-[#3B5E3A]">Always On</span>
                </div>
              ))}
              <p className={`text-sm ${muted} mt-2 leading-relaxed`}>All privacy protections are always-on and cannot be disabled.</p>
            </div>
          )}

          {active === 'Account' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold">Account</h2>
              <div className={`rounded-xl p-4 flex items-center gap-4 ${isDark ? 'bg-[#2A1C0A]' : 'bg-[#EDE8DF]'}`}>
                <div className="w-12 h-12 bg-[#5A3E1B] rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {userName ? userName.charAt(0).toUpperCase() : 'U'}
                </div>
                <div>
                  <p className="font-semibold text-sm">{userName || 'User Name'}</p>
                  <p className={`text-xs ${muted}`}>{userEmail || 'user@example.com'}</p>
                </div>
              </div>
              <button className={`px-4 py-2.5 rounded-xl text-sm font-medium border transition-all ${isDark ? 'border-[#3A2910] text-gray-400 hover:bg-[#2A1C0A]' : 'border-[#C8A97E]/40 text-gray-600 hover:bg-[#EDE8DF]'}`}>
                Change Password
              </button>
            </div>
          )}

          {active === 'Danger Zone' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-red-400">Danger Zone</h2>
              <div className="rounded-xl border border-red-500/30 p-5 bg-red-950/20 space-y-4">
                <div>
                  <p className="font-semibold text-sm text-red-400">Delete All Data</p>
                  <p className={`text-xs ${muted} mt-1 mb-3`}>Permanently delete all analytics data. This cannot be undone.</p>
                  <button className="px-4 py-2 rounded-xl bg-red-500/20 text-red-400 text-sm font-medium border border-red-500/30 hover:bg-red-500/30 transition-all">
                    Delete All Data
                  </button>
                </div>
                <div className={`border-t pt-4 ${isDark ? 'border-red-900/50' : 'border-red-200'}`}>
                  <p className="font-semibold text-sm text-red-400">Delete Account</p>
                  <p className={`text-xs ${muted} mt-1 mb-3`}>Permanently delete your account and all associated data.</p>
                  <button className="px-4 py-2 rounded-xl bg-red-500 text-white text-sm font-medium hover:bg-red-600 transition-all">
                    Delete Account
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
