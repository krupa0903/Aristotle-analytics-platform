'use client';
import { useEffect, useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { AlertTriangle, Eye, MousePointer, AlertCircle, Users } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function DashboardPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetch(`/api/data?site_id=${localStorage.getItem('site_id') || 'demo-site'}`)
      .then(r => r.json())
      .then(setData);
  }, []);

  if (!data) return <div className="p-6 text-gray-400">Loading...</div>;

  const trafficData = data.weeklyTraffic.map((d: any) => ({
    day: new Date(d.date).toLocaleDateString('en', { weekday: 'short' }),
    value: parseInt(d.views)
  }));

  const card = isDark ? 'bg-[#211507] border border-[#2A1C0A]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';
  const gridLine = isDark ? '#1E1E1E' : '#E5E7EB';
  const axisColor = isDark ? '#555' : '#9CA3AF';
  const tooltipBg = isDark ? '#1A1A1A' : '#fff';
  const tooltipBorder = isDark ? '#2A2A2A' : '#E5E7EB';

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>
      {data.aiInsight && (
        <div className="rounded-2xl border border-emerald-500/30 bg-[#3B5E3A]/5 p-4 flex items-start gap-3">
          <AlertTriangle size={18} className="text-[#3B5E3A] mt-0.5 shrink-0" />
          <div>
            <p className="font-semibold text-[#3B5E3A] text-sm mb-0.5">AI Anomaly Alert</p>
            <p className={`text-sm ${muted}`}>{data.aiInsight}</p>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: <Eye size={20} />, value: data.todayViews.toLocaleString(), label: 'Pageviews Today', alert: false },
          { icon: <MousePointer size={20} />, value: data.heatmapData.length.toLocaleString(), label: 'Total Clicks', alert: false },
          { icon: <AlertCircle size={20} />, value: data.rageClicks.toLocaleString(), label: 'Rage Clicks', alert: true },
          { icon: <Users size={20} />, value: data.funnel[0]?.users.toLocaleString() ?? '0', label: 'Funnel Users', alert: false },
        ].map((s, i) => (
          <div key={i} className={`rounded-2xl p-5 card-hover ${s.alert ? 'bg-red-950/40 border border-red-500/40' : card}`}>
            <div className={`mb-2 ${s.alert ? 'text-red-400' : muted}`}>{s.icon}</div>
            <div className={`text-3xl font-bold mb-1 ${s.alert ? 'text-red-400' : ''}`}>{s.value}</div>
            <div className={`text-xs ${s.alert ? 'text-red-400/70' : muted}`}>{s.label}</div>
          </div>
        ))}
      </div>

      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4">Traffic Last 7 Days</h3>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={trafficData} barSize={28}>
            <CartesianGrid strokeDasharray="3 3" stroke={gridLine} vertical={false} />
            <XAxis dataKey="day" tick={{ fill: axisColor, fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: axisColor, fontSize: 12 }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={{ background: tooltipBg, border: `1px solid ${tooltipBorder}`, borderRadius: 8, fontSize: 12 }} />
            <Bar dataKey="value" fill="#7C3AED" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4">Top Pages</h3>
        <div className={`grid grid-cols-2 pb-2 mb-1 border-b text-xs ${muted} ${isDark ? 'border-[#2A1C0A]' : 'border-gray-100'}`}>
          <span>Page</span><span className="text-right">Views</span>
        </div>
        {data.topPages.map((p: any, i: number) => (
          <div key={i} className={`grid grid-cols-2 py-2.5 border-b last:border-0 ${isDark ? 'border-[#2A1C0A]' : 'border-gray-50'}`}>
            <span className="text-sm font-mono">{p.page}</span>
            <span className="text-sm text-right">{parseInt(p.views).toLocaleString()}</span>
          </div>
        ))}
      </div>

      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4">Privacy Nutrition Label</h3>
        <div className="flex flex-wrap gap-2">
          {['No Cookies', 'No IP Storage', 'GDPR Compliant', 'Under 5KB Script', 'No Cross-Site Tracking'].map((b, i) => (
            <span key={i} className="px-4 py-1.5 rounded-full border border-[#3B5E3A]/50 text-[#3B5E3A] text-xs font-medium bg-[#3B5E3A]/5">{b}</span>
          ))}
        </div>
      </div>
    </div>
  );
}