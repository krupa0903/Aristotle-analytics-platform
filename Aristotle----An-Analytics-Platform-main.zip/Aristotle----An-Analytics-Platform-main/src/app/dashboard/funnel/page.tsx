'use client';
import { useTheme } from '@/contexts/ThemeContext';
import { ArrowDown, AlertTriangle } from 'lucide-react';

const funnelSteps = [
  { step: 1, path: '/home', visitors: 12543, dropoff: null, percentage: 100, color: '#3B5E3A', gravityScore: 98, gravityColor: '#3B5E3A' },
  { step: 2, path: '/pricing', visitors: 8932, dropoff: -29, percentage: 71, color: '#A67C52', gravityScore: 76, gravityColor: '#A67C52' },
  { step: 3, path: '/checkout', visitors: 3421, dropoff: -62, percentage: 27, color: '#8B2500', gravityScore: 42, gravityColor: '#8B2500' },
];

export default function FunnelPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const card = isDark ? 'bg-[#211507] border border-[#3A2910]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-[#3B5E3A]' : 'text-[#5A3E1B]/70';

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>
      <h1 className="text-xl font-bold" style={{ fontFamily: "'DM Serif Display', serif" }}>Conversion Funnel Analysis</h1>

      <div className={`rounded-2xl p-6 ${card} space-y-2`}>
        {funnelSteps.map((s, i) => (
          <div key={s.step}>
            <div className="flex items-center justify-between mb-2">
              <div>
                <span className={`text-xs ${muted} mr-2`}>Step {s.step}</span>
                <span className="text-sm font-mono font-semibold">{s.path}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-sm font-bold">{s.visitors.toLocaleString()}</div>
                  <div className={`text-xs ${muted}`}>visitors</div>
                </div>
                {s.dropoff && <span className="text-xs text-red-400 font-semibold">{s.dropoff}%</span>}
                <span className="px-2.5 py-1 rounded-full text-xs font-semibold" style={{ background: `${s.gravityColor}20`, color: s.gravityColor, border: `1px solid ${s.gravityColor}40` }}>
                  Gravity Score: {s.gravityScore}
                </span>
              </div>
            </div>
            <div className={`h-12 rounded-xl overflow-hidden ${isDark ? 'bg-[#2A1C0A]' : 'bg-[#EDE8DF]'}`}>
              <div className="h-full rounded-xl flex items-center px-4 text-white font-bold text-sm" style={{ width: `${s.percentage}%`, background: s.color }}>
                {s.percentage}%
              </div>
            </div>
            {i < funnelSteps.length - 1 && (
              <div className="flex justify-center py-2"><ArrowDown size={16} className={muted} /></div>
            )}
          </div>
        ))}
      </div>

      <div className={`rounded-2xl p-6 ${card}`}>
        <h3 className="font-semibold text-sm mb-6" style={{ fontFamily: "'DM Serif Display', serif" }}>Drop-off Map</h3>
        <div className="flex gap-8">
          <div className="flex-1 flex flex-col items-center">
            {[
              { path: '/home', visitors: 12543, exitPct: '29%', color: '#3B5E3A' },
              { path: '/pricing', visitors: 8932, exitPct: '62%', color: '#A67C52' },
              { path: '/checkout', visitors: 3421, exitPct: null, color: '#8B2500' },
            ].map((node, i, arr) => (
              <div key={node.path} className="flex flex-col items-center w-full">
                <div className="w-44 rounded-xl p-4 text-center border" style={{ borderColor: `${node.color}60`, background: `${node.color}10` }}>
                  <p className="font-mono font-semibold text-sm">{node.path}</p>
                  <p className={`text-xs mt-1 ${muted}`}>{node.visitors.toLocaleString()} visitors</p>
                </div>
                {node.exitPct && i < arr.length - 1 && (
                  <div className="flex flex-col items-center my-1">
                    <p className="text-xs text-red-400 font-medium">{node.exitPct} exit</p>
                    <ArrowDown size={14} className={muted} />
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="flex flex-col gap-3 justify-center">
            {[
              { color: 'bg-[#3B5E3A]', label: '71% continue', textColor: 'text-[#3B5E3A]' },
              { color: 'bg-red-500', label: '29% drop', textColor: 'text-red-400' },
              { color: 'bg-[#A67C52]', label: '38% continue', textColor: 'text-[#3B5E3A]', mt: true },
              { color: 'bg-red-500', label: '62% drop', textColor: 'text-red-400' },
            ].map((item, i) => (
              <div key={i} className={`flex items-center gap-2 ${item.mt ? 'mt-4' : ''}`}>
                <div className={`w-8 h-2 rounded-full ${item.color}`} />
                <span className={`text-xs ${item.textColor}`}>{item.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="rounded-2xl p-4 bg-red-950/30 border border-red-500/30 flex items-start gap-3">
        <AlertTriangle size={18} className="text-red-400 mt-0.5 shrink-0" />
        <div>
          <p className="font-semibold text-red-400 text-sm mb-1" style={{ fontFamily: "'DM Serif Display', serif" }}>Biggest Drop-off</p>
          <p className={`text-sm ${muted}`}>
            <span className="text-red-400 font-semibold">62% drop-off</span> detected between{' '}
            <code className="bg-red-900/30 px-1 py-0.5 rounded text-xs">/pricing</code> and{' '}
            <code className="bg-red-900/30 px-1 py-0.5 rounded text-xs">/checkout</code>.
            Consider optimizing the pricing page CTA or simplifying the checkout flow.
          </p>
        </div>
      </div>

      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4" style={{ fontFamily: "'DM Serif Display', serif" }}>Gravity Score Explained</h3>
        <div className="grid grid-cols-3 gap-3">
          {[
            { range: '80-100: Excellent', desc: 'Strong user retention, minimal friction', cls: 'bg-[#3B5E3A]/10 text-[#3B5E3A] border-[#3B5E3A]/30' },
            { range: '50-79: Good', desc: 'Acceptable flow, room for improvement', cls: 'bg-[#A67C52]/10 text-[#3B5E3A] border-[#A67C52]/30' },
            { range: '0-49: Needs Work', desc: 'High drop-off, requires optimization', cls: 'bg-red-500/10 text-red-400 border-red-500/30' },
          ].map((g, i) => (
            <div key={i} className={`rounded-xl p-4 border ${g.cls}`}>
              <p className="text-sm font-semibold mb-1">{g.range}</p>
              <p className="text-xs opacity-80">{g.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}