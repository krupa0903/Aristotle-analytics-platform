'use client';
import { useEffect, useState } from 'react';
import { useTheme } from '@/contexts/ThemeContext';
import { Users } from 'lucide-react';

const locations = [
  { city: 'New York', country: 'United States', flag: '🇺🇸', users: 342, x: 22, y: 38 },
  { city: 'London', country: 'United Kingdom', flag: '🇬🇧', users: 198, x: 46, y: 30 },
  { city: 'Tokyo', country: 'Japan', flag: '🇯🇵', users: 156, x: 78, y: 36 },
  { city: 'Paris', country: 'France', flag: '🇫🇷', users: 89, x: 48, y: 33 },
  { city: 'Sydney', country: 'Australia', flag: '🇦🇺', users: 67, x: 82, y: 68 },
];

export default function LiveUsersPage() {
  const { resolvedTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [liveCount, setLiveCount] = useState(902);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveCount(prev => Math.max(850, prev + Math.floor(Math.random() * 7) - 3));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  const card = isDark ? 'bg-[#211507] border border-[#3A2910]' : 'bg-white border border-[#C8A97E]/40 shadow-sm';
  const muted = isDark ? 'text-[#3B5E3A]' : 'text-[#5A3E1B]/70';

  return (
    <div className="p-6 max-w-[1400px] mx-auto space-y-6" style={{ animation: 'fadeIn 0.3s ease' }}>
      <div className="flex items-center gap-3">
        <h1 className="text-xl font-bold" style={{ fontFamily: "'DM Serif Display', serif" }}>Live Users Map</h1>
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500" />
          </span>
          <span className="text-xs text-red-400 font-medium">LIVE</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className={`rounded-2xl p-5 ${card}`}>
          <div className="flex items-center gap-2 mb-2">
            <Users size={16} className="text-[#3B5E3A]" />
            <span className={`text-xs ${muted}`}>Live Users Right Now</span>
          </div>
          <div className="text-3xl font-bold tabular-nums">{liveCount.toLocaleString()}</div>
        </div>
        <div className={`rounded-2xl p-5 ${card}`}>
          <p className={`text-xs ${muted} mb-2`}>Most Active Country</p>
          <p className="text-lg font-bold">🇺🇸 United States</p>
        </div>
        <div className={`rounded-2xl p-5 ${card}`}>
          <p className={`text-xs ${muted} mb-2`}>Most Active City</p>
          <p className="text-lg font-bold">New York</p>
        </div>
      </div>

      <div className={`rounded-2xl overflow-hidden ${card}`}>
        <div className="relative w-full" style={{ height: '380px', background: isDark ? '#1A1108' : '#F5F0E8' }}>
          <div className="absolute inset-0 opacity-15" style={{
            backgroundImage: `linear-gradient(${isDark ? '#3A2910' : '#C8A97E'} 1px, transparent 1px), linear-gradient(90deg, ${isDark ? '#3A2910' : '#C8A97E'} 1px, transparent 1px)`,
            backgroundSize: '60px 60px',
          }} />
          {locations.map((loc, i) => {
            const size = Math.max(20, Math.min(70, loc.users / 6));
            return (
              <div key={loc.city} className="absolute group" style={{ left: `${loc.x}%`, top: `${loc.y}%` }}>
                <div className="absolute rounded-full animate-ping" style={{
                  width: size * 1.8, height: size * 1.8, left: -(size * 0.9), top: -(size * 0.9),
                  background: 'radial-gradient(circle, rgba(90,62,27,0.2) 0%, transparent 70%)',
                  animationDuration: `${2 + i * 0.4}s`,
                }} />
                <div className="rounded-full" style={{
                  width: size, height: size, marginLeft: -(size / 2), marginTop: -(size / 2),
                  background: 'radial-gradient(circle, rgba(90,62,27,0.9) 0%, rgba(166,124,82,0.4) 60%, transparent 100%)',
                }} />
                <div className={`absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 border rounded-xl px-3 py-2 text-xs whitespace-nowrap shadow-xl ${
                  isDark ? 'bg-[#2A1C0A] border-[#3A2910]' : 'bg-white border-[#C8A97E]/40'
                }`}>
                  <p className="font-semibold">{loc.flag} {loc.city}</p>
                  <p className={muted}>{loc.users} users</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className={`rounded-2xl p-5 ${card}`}>
        <h3 className="font-semibold text-sm mb-4" style={{ fontFamily: "'DM Serif Display', serif" }}>Top 5 Active Locations</h3>
        <div className="space-y-3">
          {locations.map(loc => (
            <div key={loc.city} className="flex items-center gap-3">
              <span className="text-base w-6 text-center">{loc.flag}</span>
              <div className="flex-1">
                <div className="flex justify-between text-sm mb-1">
                  <span className="font-medium">{loc.city}</span>
                  <span className="text-[#3B5E3A] font-semibold">{loc.users}</span>
                </div>
                <div className={`h-1.5 rounded-full overflow-hidden ${isDark ? 'bg-[#2A1C0A]' : 'bg-[#EDE8DF]'}`}>
                  <div className="h-full bg-[#5A3E1B] rounded-full" style={{ width: `${(loc.users / locations[0].users) * 100}%` }} />
                </div>
                <p className={`text-xs mt-0.5 ${muted}`}>{loc.country}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}