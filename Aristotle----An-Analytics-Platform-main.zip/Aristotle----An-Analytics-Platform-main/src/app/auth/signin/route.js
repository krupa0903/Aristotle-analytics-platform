import { Pool } from 'pg';
import crypto from 'crypto';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export async function POST(request) {
    const headers = { 'Access-Control-Allow-Origin': '*' };
    try {
        const { email, password } = await request.json();
        const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');

        const result = await pool.query(
            'SELECT id, name, email, site_id, website_url, website_name FROM users WHERE email=$1 AND password=$2', [email, hashedPassword]
        );

        if (result.rows.length === 0) {
            return Response.json({ error: 'Invalid email or password' }, { status: 401, headers });
        }

        return Response.json({ ok: true, ...result.rows[0] }, { status: 200, headers });
    } catch (err) {
        return Response.json({ error: err.message }, { status: 500, headers });
    }
}