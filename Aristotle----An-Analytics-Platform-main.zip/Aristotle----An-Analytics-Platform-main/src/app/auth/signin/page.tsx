'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Zap, Mail, Lock, Eye, EyeOff, Sun, Moon } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';

export default function SignInPage() {
  const router = useRouter();
  const { resolvedTheme, setTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';
  const [showPass, setShowPass] = useState(false);
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);
  try {
    const res = await fetch('/api/auth/signin', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form)
    });
    const data = await res.json();
    if (data.error) {
      alert(data.error);
      setLoading(false);
      return;
    }
    localStorage.setItem('site_id', data.site_id);
    localStorage.setItem('user_name', data.name);
    localStorage.setItem('user_email', data.email);
    localStorage.setItem('website_url', data.website_url);
    localStorage.setItem('website_name', data.website_name);
    router.push('/dashboard');
  } catch {
    alert('Something went wrong');
    setLoading(false);
  }
};

  const bg = isDark ? 'bg-[#1A1108] text-white' : 'bg-[#F5F0E8] text-[#2C1A0E]';
  const card = isDark ? 'bg-[#211507] border-[#3A2910]' : 'bg-white border-[#C8A97E]/40 shadow-sm';
  const inputCls = isDark
    ? 'bg-[#2A1C0A] border-[#3A2910] text-white placeholder-gray-600 focus:border-[#7C3AED]'
    : 'bg-[#EDE8DF] border-[#C8A97E]/40 text-gray-900 placeholder-gray-400 focus:border-[#7C3AED]';
  const muted = isDark ? 'text-gray-400' : 'text-gray-500';
  const labelCls = isDark ? 'text-gray-300' : 'text-gray-700';

  return (
    <div className={`min-h-screen flex flex-col items-center justify-center px-4 transition-colors duration-300 ${bg}`}>
      <button
        onClick={() => setTheme(isDark ? 'light' : 'dark')}
        className={`fixed top-5 right-5 p-2.5 rounded-full transition-all ${
          isDark ? 'bg-[#2A1C0A] hover:bg-[#2A2A2A] text-gray-300' : 'bg-white hover:bg-gray-100 text-gray-600 shadow-sm border border-[#C8A97E]/40'
        }`}
      >
        {isDark ? <Sun size={18} /> : <Moon size={18} />}
      </button>

      <div className="flex items-center gap-2.5 mb-2">
  <div className="w-8 h-8 bg-[#5A3E1B] rounded-lg flex items-center justify-center">
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="5.5" stroke="#C8A97E" strokeWidth="1.2" fill="none"/>
      <line x1="8" y1="2.5" x2="8" y2="13.5" stroke="#C8A97E" strokeWidth="1"/>
      <line x1="2.5" y1="8" x2="13.5" y2="8" stroke="#C8A97E" strokeWidth="1"/>
      <circle cx="8" cy="8" r="1.8" fill="#A67C52"/>
    </svg>
  </div>
  <span className="text-xl font-bold" style={{ fontFamily: "'DM Serif Display', serif" }}>
    Aristotle
  </span>
</div>

        <div className={`rounded-2xl border p-8 ${card}`}>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="flex items-center gap-3 mb-4" style={{ animation: 'fadeIn 0.5s ease' }}>
  <div className="w-10 h-10 bg-[#5A3E1B] rounded-xl flex items-center justify-center">
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
      <circle cx="11" cy="11" r="8" stroke="#C8A97E" strokeWidth="1.5" fill="none"/>
      <line x1="11" y1="3" x2="11" y2="19" stroke="#C8A97E" strokeWidth="1.2"/>
      <line x1="3" y1="11" x2="19" y2="11" stroke="#C8A97E" strokeWidth="1.2"/>
      <circle cx="11" cy="11" r="2" fill="#A67C52"/>
    </svg>
  </div>
  <span className="text-3xl font-bold tracking-tight" style={{ fontFamily: "'DM Serif Display', serif" }}>
    Aristotle
  </span>
</div>

<p className={`text-center text-base max-w-md mb-12 leading-relaxed ${muted}`}
   style={{ fontFamily: "'DM Sans', sans-serif", animation: 'fadeIn 0.6s ease' }}>
  Privacy-first web analytics powered by AI. Observe every click, understand every pattern.
</p>
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Email</label>
              <div className="relative">
                <Mail size={16} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input type="email" placeholder="you@example.com" value={form.email}
                  onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required
                  className={`w-full pl-10 pr-4 py-3 rounded-xl border text-sm outline-none transition-colors ${inputCls}`} />
              </div>
            </div>
            <div>
              <label className={`text-sm font-medium mb-1.5 block ${labelCls}`}>Password</label>
              <div className="relative">
                <Lock size={16} className={`absolute left-3.5 top-1/2 -translate-y-1/2 ${muted}`} />
                <input type={showPass ? 'text' : 'password'} placeholder="Enter your password" value={form.password}
                  onChange={e => setForm(f => ({ ...f, password: e.target.value }))} required
                  className={`w-full pl-10 pr-10 py-3 rounded-xl border text-sm outline-none transition-colors ${inputCls}`} />
                <button type="button" onClick={() => setShowPass(v => !v)} className={`absolute right-3.5 top-1/2 -translate-y-1/2 ${muted}`}>
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="w-full py-3 bg-[#5A3E1B] hover:bg-[#3B5E3A] text-white rounded-xl font-semibold text-sm transition-all disabled:opacity-70">
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
          <p className={`text-center text-sm mt-6 ${muted}`}>
            Don&apos;t have an account?{' '}
            <Link href="/auth/signup" className="text-[#3B5E3A] font-medium hover:underline">Sign Up</Link>
          </p>
        </div>
      </div>
  );
}